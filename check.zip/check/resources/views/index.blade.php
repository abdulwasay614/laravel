@foreach($stu as $student)

@php
var_dump($student);
echo "<br>";

//var_dump($student->teac);
echo "<br>";

//var_dump($stu->teac);


@endphp


@endforeach