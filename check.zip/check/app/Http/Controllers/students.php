<?php

namespace App\Http\Controllers;
use App\Models\student;
use Illuminate\Http\Request;

class students extends Controller
{
    public function index()
    {
        $stu=student::with('teac')->get();

        return view('index',['stu'=>$stu]);
        
    }
}
