<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class teachers extends Controller
{
    //
}
