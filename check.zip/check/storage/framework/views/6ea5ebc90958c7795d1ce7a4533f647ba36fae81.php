<?php $__currentLoopData = $stu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php
var_dump($student);
echo "<br>";

//var_dump($student->teac);
echo "<br>";

//var_dump($stu->teac);


?>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\assigment\check\resources\views/index.blade.php ENDPATH**/ ?>